
var monkey , monkey_running;
var banana ,bananaImage, stones, obstacleImage
var FoodGroup, stoneGroup
var score
var ground,fruits,fruitImage,fruit;
var PLAY = 1;
var END = 0;
var gameState = 1;


function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(400,400);
  monkey=createSprite(100,390,20,50);
  monkey.addAnimation("running",monkey_running);
  monkey.scale=0.1;

  ground=createSprite(320,390,800,10);
  ground.velocityX=-4;
  
  FoodGroup=createGroup();
  stoneGroup=createGroup();

  score = 0;
  
}


function draw() {
   background("white");
  
  text("Survival Time; " + score,160,100);
  
  
  if(gameState===PLAY){
     if(keyDown("space")&& monkey.y >=340){
     monkey.velocityY=-13; 
   }
    
    score = score + Math.round(getFrameRate()/60);
    
    
  if(ground.x > 0){
    ground.x=ground.width / 2;  
  }
    monkey.velocityY=monkey.velocityY+0.8;  
  }
  
  fruits();
  stones();
  
  
  if(gameState===END){
  
    
  }
  
  monkey.collide(ground);
  drawSprites();
}
function reset(){
  gameState=END;
  
}

function fruits(){
  if(World.frameCount % 80===0){
    fruit=createSprite(400,250,10,10);
    fruit.addImage(bananaImage);
    fruit.scale=0.1;
    
    fruit.velocityX=-10;
    
    FoodGroup.add(fruit);
  
  }
    fruits.lifetime=100;
}

function stones(){
  if(World.frameCount % 60===0){
    stone=createSprite(400,370,10,10);
    stone.addImage(obstacleImage);
    stone.scale=0.1;
    
    stone.velocityX=-10; 
    stoneGroup.add(stone);
  } 
}





